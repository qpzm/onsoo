#Kimhaeun
#22100224
#Quiz1
#Problem3

num=int(input("어디까지 더해 보실래요?"))
add=(num+1)*(num/2)
ave=add/num

print("1과",num,"사이의 정수를 누적하여 더한 값은",add)
print("평균은", ave)
