#Kimhaeun
#22100224
#Problem1
count=0
word=['Apple','box','buzz','CANTUS','dish','knife','lady','pitch','stimulus','wish','wolf']
t=[]

for i in word:
    count=0
    t=[]
    for char in i:
        if char=='a' or char=='A'or char=='e' or char=='E' or char=='i' or char=='I' or char=='o' or char=='O' or char=='u' or char=='U':
            count=count+1
            t.append(char)
    print(i,',',t,"로 모음",count,"개")
    
