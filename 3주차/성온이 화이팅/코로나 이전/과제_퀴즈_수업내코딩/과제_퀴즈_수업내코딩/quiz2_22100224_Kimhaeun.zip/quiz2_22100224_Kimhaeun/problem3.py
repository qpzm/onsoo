#Kimhaeun
#22100224
#Problem3

sum=0
a=0
n1=int(input("첫번째 양의 정수를 입력해주세요:"))
n2=int(input("두번째 양의 정수를 입력해주세요:"))

if n1<=0 or n2<=0:
    print("양의 정수가 아니라서 입력 에러입니다.")
elif n1<n2:
    if(n2-n1)%2==0:
        for i in range(n1,n2,2):
            sum=sum+i-(i+1)
            a=i+1
            print(i,'-',a,'+',end=' ')
        sum=sum+n2
        print(n2,'=',sum)
    else:
        for i in range(n1,n2+1,2):
            sum=sum+i-(i+1)
            a=i+1
            if a==(n2):
                print(i,'-',a,end=' ')
            else:
                print(i,'-',a,'+',end=' ')
            
        print('=',sum)
 
elif n1>n2:
    if(n1-n2)%2==0:
        for i in range(n1,n2,-2):
            sum=sum+i-(i-1)
            a=i-1
            print(i,'-',a,'+',end=' ')
        sum=sum+n2
        print(n2,'=',sum)
    else:
        for i in range(n1,n2-1,-2):
            sum=sum+i-(i-1)
            a=i-1
            if a==(n2):
                print(i,'-',a,end=' ')
            else:
                print(i,'-',a,'+',end=' ')
            
        print('=',sum)

        
