#Kimhaeun
#22100224
#Adding and Multiplying

number1 = int(input('첫번째 숫자를 입력하시오: '))
number2 = int(input('두번째 숫자를 입력하시오: '))

print('더한 결과는 ',number1+number2,'이고, 곱한 결과는 ', number1*number2,'입니다.')
