#Kimhaeun
#22100224
#Address

도 = input('도: ')
시 = input('시: ')
구 = input('구: ')
나머지 = input('나머지: ')

print('저의 주소는 ',도,시,구,나머지,'입니다.')
