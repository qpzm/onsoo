#Kimhaeun
#22100224
#name and age

name = input('이름을 입력하시오: ')
age = input('나이를 입력하시오: ')
print(name,',',age)
